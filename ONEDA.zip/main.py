import asyncio
import json
import time
import aiohttp
import websockets
import sys
import socket

# CONFIGURATION
TOKEN = "NDI0NzAzMDM2NjU3NjMxMjQz.GFWU4x.fXDprcEoO9Fwd2xtL-C6ig5uOatTfG3_9oo9xY"
CATEGORY_ID = "1471552516419485748"
RESPONSE_MSG = "Olá! Como posso ajudar você hoje?"

# API URLS
GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"
API_HOST = "discord.com"
API_BASE = f"https://{API_HOST}/api/v10"

class UltimateConsistencyBot:
    def __init__(self, token, category_id, message):
        self.token = token
        self.category_id = str(category_id)
        self.message = message
        self.sessions = []
        self.processed_channels = set()
        self.success_channels = set() # Canais que já tiveram resposta confirmada
        self.last_sequence = None
        self.heartbeat_interval = None
        
        self.headers = {
            "Authorization": self.token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
        }
        self.payload = json.dumps({"content": self.message}).encode('utf-8')

    async def start(self):
        # DNS Prefetching
        try: socket.gethostbyname(API_HOST)
        except: pass

        connector_settings = {"limit": 0, "ttl_dns_cache": 600, "use_dns_cache": True}
        
        # Reduzido para 2 sessões para evitar spam triplo, mas mantendo redundância
        async with aiohttp.ClientSession(headers=self.headers, connector=aiohttp.TCPConnector(**connector_settings)) as s1, \
                   aiohttp.ClientSession(headers=self.headers, connector=aiohttp.TCPConnector(**connector_settings)) as s2:
            
            self.sessions = [s1, s2]
            
            # Aquecimento
            await asyncio.gather(*(s.get(f"{API_BASE}/users/@me") for s in self.sessions), return_exceptions=True)
            asyncio.create_task(self.sessions_heater())
            
            await self.connect_gateway()

    async def sessions_heater(self):
        while True:
            await asyncio.sleep(4)
            for s in self.sessions:
                try: asyncio.create_task(s.get(f"{API_BASE}/gateway"))
                except: pass

    async def connect_gateway(self):
        async with websockets.connect(GATEWAY_URL, max_size=None) as ws:
            print(f"[*] BOT ESTÁVEL ATIVO. (Modo Anti-Duplicação)")
            
            cat_id = self.category_id
            json_loads = json.loads
            create_task = asyncio.create_task

            async for message in ws:
                # Gatilho ultra-rápido
                if cat_id in message and '"t":"CHANNEL_CREATE"' in message:
                    try:
                        data = json_loads(message)
                        cid = data['d']['id']
                        if str(data['d'].get('parent_id')) == cat_id:
                            if cid not in self.processed_channels:
                                self.processed_channels.add(cid)
                                # DISPARO ESCALONADO (Staggered Racing)
                                # Dispara no túnel 1 AGORA
                                create_task(self.dispatch(self.sessions[0], cid, "T1"))
                                # Dispara no túnel 2 após 25ms (Tempo suficiente para evitar 
                                # duplicatas na maioria das vezes, mas rápido o suficiente 
                                # para cobrir falhas de rede do Túnel 1)
                                create_task(self.delayed_dispatch(self.sessions[1], cid, "T2", 0.025))
                    except: pass

                # Gateway Maintenance
                if '"op":10' in message:
                    data = json_loads(message)
                    self.heartbeat_interval = data["d"]["heartbeat_interval"] / 1000
                    create_task(self.heartbeat(ws))
                    await self.identify(ws)
                elif '"s":' in message:
                    try:
                        data = json_loads(message)
                        self.last_sequence = data.get("s", self.last_sequence)
                        if data.get("t") == "READY":
                            print(f"[*] On: {data['d']['user']['username']}")
                    except: pass

    async def delayed_dispatch(self, session, cid, tag, delay):
        await asyncio.sleep(delay)
        # Se o primeiro túnel já confirmou sucesso, o segundo nem tenta
        if cid not in self.success_channels:
            await self.dispatch(session, cid, tag)

    async def dispatch(self, session, cid, tag):
        if cid in self.success_channels: return
        
        url = f"{API_BASE}/channels/{cid}/messages"
        start = time.perf_counter()
        try:
            async with session.post(url, data=self.payload) as resp:
                lat = (time.perf_counter() - start) * 1000
                if resp.status == 200:
                    self.success_channels.add(cid)
                    print(f"[+] {tag} WIN! {lat:.2f}ms")
                elif resp.status == 404:
                    # Retry ultra-rápido apenas para propagação
                    await asyncio.sleep(0.12)
                    if cid not in self.success_channels:
                        async with session.post(url, data=self.payload) as r2:
                            if r2.status == 200: self.success_channels.add(cid)
        except: pass

    async def identify(self, ws):
        await ws.send(json.dumps({
            "op": 2, "d": {
                "token": self.token,
                "properties": {"os": "Windows", "browser": "Chrome", "device": ""},
                "compress": False, "large_threshold": 50
            }
        }))

    async def heartbeat(self, ws):
        while True:
            await asyncio.sleep(self.heartbeat_interval)
            try: await ws.send(json.dumps({"op": 1, "d": self.last_sequence}))
            except: break

if __name__ == "__main__":
    bot = UltimateConsistencyBot(TOKEN, CATEGORY_ID, RESPONSE_MSG)
    try: asyncio.run(bot.start())
    except KeyboardInterrupt: pass
